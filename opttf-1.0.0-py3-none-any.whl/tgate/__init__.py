from .PixArt_Alpha import TgatePixArtAlphaLoader
from .PixArt_Sigma import TgatePixArtSigmaLoader
from .SD import TgateSDLoader
from .SD_DeepCache import TgateSDDeepCacheLoader
from .SDXL import TgateSDXLLoader
from .SDXL_DeepCache import TgateSDXLDeepCacheLoader
from .SVD import TgateSVDLoader
